import { BaseSchema } from '@adonisjs/lucid/schema'

export default class extends BaseSchema {
  async up() {
    this.schema.alterTable('social_identities', (table) => {
      table.timestamp('confirmed_at', { useTz: true }).nullable()
    })
  }

  async down() {
    this.schema.alterTable('social_identities', (table) => {
      table.dropColumn('confirmed_at')
    })
  }
}
