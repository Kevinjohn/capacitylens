import { BaseSchema } from '@adonisjs/lucid/schema'

export default class extends BaseSchema {
  async up() {
    this.schema.createTable('account_transaction_lock', (table) => {
      table.integer('id').primary()
      table.integer('version').notNullable().defaultTo(0)
    })
    this.defer(async (db) => {
      await db.table('account_transaction_lock').insert({ id: 1, version: 0 })
    })
  }

  async down() {
    this.schema.dropTable('account_transaction_lock')
  }
}
