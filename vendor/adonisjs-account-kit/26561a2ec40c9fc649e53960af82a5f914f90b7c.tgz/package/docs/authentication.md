# Authentication integration

## Configuration

Set `authentication` in `defineConfig` to one supported strategy and the name of an **existing** AdonisJS Auth guard. The package does not install or replace a guard. Use one managed route group with either `session` or `access_tokens`; two managed groups over the same accounts are unsupported.

```ts
authentication: {
  strategy: 'session', // or 'access_tokens'
  guard: 'web',         // existing guard name; 'api' in the token example
  canAccess: async (user, trx) => /* application restriction lookup */ true,
  clientLimit: { requests: 10, duration: '1m' },
  identityLimit: { requests: 5, duration: '1m', blockDuration: '20m' },
  tokenAbilities: ['*'],          // token guard only
  tokenExpiresIn: '1d',          // token guard only; omitted means no expiry
  tokenTable: 'auth_access_tokens', // token guard only
}
```

The `canAccess` callback runs under the account lock before login and on protected access. Use `kit.authentication.changeRestriction({ userId, change })` for package-managed restriction changes. Its callback writes through the supplied transaction; the package then advances the credential revision and applies the selected revocation policy in that transaction. The default callback permits access. Account activation is a separate state: an inactive account may hold a limited credential, but `requireActive` denies protected actions with HTTP 403 and code `unverified_email`.

Session authentication requires AdonisJS Auth and Session, a **server-side session store** that can destroy the current session, secure HTTP-only cookies, and Shield CSRF protection. The maintained example rejects the cookie session store because a previously issued self-contained cookie could be replayed after logout. Use a shared server-side store for multiple application instances; an instance-local memory store is suitable only for the single-instance fixture. Disable remember-me tokens unless their independent revocation is implemented and tested. Configure trusted proxy addresses before using `request.ip()` for the client limiter. Set a fixed public HTTPS origin and explicit CORS/origin policy for your browser client. CORS does not authenticate requests. JSON requests still require CSRF protection when cookies establish authority.

Token authentication requires AdonisJS Auth's opaque access-token provider and its token table. Choose an explicit `tokenExpiresIn` for a finite lifetime and narrow `tokenAbilities` for privileged APIs. The selected guard authenticates the token and checks expiry; privileged routes must explicitly check `user.currentAccessToken.allows('required:ability')` before acting. The example checks `invitations:create` before sending an invitation. Store bearer credentials only in a client location appropriate to the threat model, send them in the `Authorization: Bearer` header, and never put them in URLs or logs.

The maintained [token API reference](../examples/api/TOKENS.md) shows the complete bearer request sequence, proof-link handling, error envelopes, and application-owned route gate.

## How it works

`kit.authentication.login({ email, password, clientKey }, guard)` checks the package user adapter's password verifier and selected `canAccess` policy. It returns one public `Invalid email or password` failure for absent accounts, wrong passwords, disabled access, and passwordless accounts. Every such failure waits until `minRequestMs` has elapsed, so failure timing does not reveal which addresses have usable accounts; keep it above the password hash cost. Failed attempts consume both HMAC-keyed limits; successful attempts do not consume either. A successful login resets only that identity's failure count; it preserves failures against other identities on the shared client. The client budget is 10 failures per minute and the client-plus-normalized-email budget is five failures per minute with a 20-minute block. Concurrent attempts already in progress can complete before their failures enter the client budget; subsequent attempts observe the accumulated failures. The application derives `clientKey` from a trusted request IP, never from a caller-provided field. The guard port supplies the configured `name` and `strategy` and establishes a real AdonisJS session or token. It is an adapter boundary, not another credential store.

The session adapter records the current `credentials_changed_at` revision in the session when the real guard logs in. The package checks it against the database on each protected request. A missing or stale revision fails closed. Login rechecks revision and restrictions after provisional establishment, and terminates a credential created during an intervening account change. Token login uses the configured abilities and expiry, then similarly deletes a provisional token if the revision changed. A login that verifies an old password before a committed reset cannot return usable access. Package password reset, password change, confirmed-email change, restriction changes, and social unlink advance the revision. Token mode deletes **all** of that user's bearer tokens in the same transaction; session mode rejects existing browser sessions through the revision check. The revision advances even when repeated changes share one clock tick. These guarantees apply across instances sharing the same database and, for sessions, a shared session store.

The selected guard authenticates a request first; call `kit.authentication.current({ userId, revision })` for safe account data and `requireActive` for verified routes. Session requests must pass their captured revision, including an initial null value. Token requests must pass the current guard's trusted token identifier; the package checks that its row is still bound to the user under the account lock. This also rejects a request whose token was revoked between guard authentication and protected access. These methods return only ID, email, pending email, password availability, and active state. The maintained example applies `AccountAccessMiddleware` to limited routes and `VerifiedAccountMiddleware` to verified routes, whether package-backed or application-owned. Any application-owned route that omits the appropriate gate is outside its revocation or verified-account guarantee. The email-correction and activation-send routes permit a limited inactive credential while still checking revocation and restrictions. Direct application writes to email, password, verification state, restrictions, or provider rows are likewise outside package revocation and proof invalidation; use package operations. The Lucid save hook still hashes a password on a direct save.

For a session JSON client, first GET `/api/v1/auth/csrf`, retain the HTTP-only session cookie, then send the returned CSRF token in `x-csrf-token` on login and other state-changing requests. Login regenerates the session identifier. Logout destroys the current server-side session; an old cookie fails, and a repeated authenticated logout returns 401 because that credential no longer exists. In token mode, login returns an opaque token, logout deletes the current token, and a repeat with the same token returns 401. Logout does not mean universal revocation; credential changes have the per-guard policy above. Responses never put credentials in URLs.

## Files delta

`src/authentication.ts` owns the service and revision checks; `src/config.ts`, `src/types.ts`, and `src/errors.ts` define the public contract. `configure.ts` emits `add_credentials_changed_at_to_users` as the ninth package migration, and the example includes its matching migration. The example's selected-guard controllers, Shield configuration, access middleware, and functional tests show both supported modes. The generic service declarations do not import optional Auth or Session packages; the concrete example adapters do.

## Manual steps

Review and apply the new users-table migration before activating authentication. Verify that the existing guard, token table or server-side session store, CSRF middleware, trusted proxies, public origin, and application-owned route middleware match the chosen mode. Back up user and token tables before migrating. For multiple instances, use a shared limiter and session store, and deploy the middleware everywhere before accepting new sessions. Disable remember-me tokens unless their revocation policy is separately enforced. Existing browser sessions have no captured revision and must sign in again. Review direct account writes and move changes that require revocation to package operations. Run the SQLite and PostgreSQL suites plus both packed consumer modes before deployment.

## Changelog

See the [Unreleased entries](../CHANGELOG.md#unreleased) for the new authentication, guard, revision, and migration contracts.
