# Changelog

## 0.1.1 - 2026-11-08

- Clarify credential-revision comments and remove obsolete drafting notes; runtime behavior is unchanged.

## 0.1.0 - 2026-11-08

- First version: password-confirmed, single-use action proofs on Account Kit 0.3.1.
  - Two-stage issuance with the hash outside the Kit lock.
  - A configurable window (default 5 minutes) from `verified_at`.
  - Spend inside the caller's `withCurrent` transaction.
  - Binding to sign-in, live credential revision, action, scope and intent.
  - `node ace configure` publishes config, migration and provider; `prune()` removes spent and expired proofs.
  - Per-account wrong-password throttle that reserves an attempt atomically before the hash.
  - `--table` configure flag; the migration indexes `user_id` and `consumed_at`.
  - Host `authorize` receives only action, scope and intent; unsafe integers in an intent are refused.
