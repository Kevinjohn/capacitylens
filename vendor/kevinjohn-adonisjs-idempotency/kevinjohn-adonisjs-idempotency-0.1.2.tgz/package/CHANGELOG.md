# Changelog

## 0.1.2

### Fixed

- Require a parser when the operation authorization type excludes `undefined`, preserving callback
  inference and preventing parserless commands from receiving an incorrectly typed authorization.
- An aborted nested command stops before parsing authorization when its reservation settles after
  its parent starts unwinding.
- Clarify that replay denial preserves the completed receipt for a later permitted replay.

## 0.1.1

### Changed

- `authorizeReplay`, `parseAuthorization` and `authorizeExecute` are optional. Omitted policies allow
  replay or execution; without a parser, fresh callbacks receive `undefined` authorization.

## 0.1.0

### Added

- `execute` (managed transaction) and `executeIn` (host transaction) with unique-index reservation,
  conditional `pending` → `completed` completion, and `authorizeAccess` / `authorizeReplay` /
  `authorizeExecute` policies with an opaque `authorization` parsed only after a fresh reservation.
- SQLite single-connection pool check (`E_UNSAFE_SQLITE_POOL`), and the SQLite writer lock taken
  before the first read.
- `pruneReceipts`, typed errors, and `node ace configure` publishing the receipts migration.
- Plain-JSON validation of payloads and results (`E_INVALID_COMMAND_VALUE`, `E_INVALID_COMMAND_RESULT`).
- `E_UNSUPPORTED_DIALECT`: only better-sqlite3 is accepted.
- The fresh path runs under a raw SQL savepoint on the caller's transaction; a failed execute never
  leaves a pending receipt, and commands nest (`executeIn` and `trx.transaction()` inside `work`).
- One command at a time per transaction: siblings get `E_CONCURRENT_COMMAND` at once, nested calls
  from the open command's policies or `work` compose, and a command completing over an open nested
  command fails with `E_UNAWAITED_NESTED_COMMAND` and rolls both back. Cleanup failures never
  replace the original error.
- A command unwinding over a running nested command aborts it and waits for it before rolling back,
  so the nested command's writes never reach the host transaction without a receipt.
- A command that has started to complete, replay or unwind refuses new nested commands with
  `E_UNAWAITED_NESTED_COMMAND`, so none can start after it stopped waiting for its children.
- `E_RECEIPT_SCHEMA` when the receipts table predates the current migration.
- Shared SQLite file detection follows symlinks, spans Database instances and releases closed connections.
- Command ids are unique per operation and actor; the operation column is a JSON tuple.
