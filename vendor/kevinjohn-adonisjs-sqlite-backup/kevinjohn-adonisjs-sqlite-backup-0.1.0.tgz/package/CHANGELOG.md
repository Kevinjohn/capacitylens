# Changelog

## 0.1.0

### Adoption capabilities

- Back up through an already-open better-sqlite3 handle without closing borrowed handles.
- Explicit private directory preparation; missing roots fail create, list and prune. Unsafe root permissions refuse writes and restore preparation.
- Disabled configuration boots and reports `E_BACKUP_DISABLED`; explicit directory recovery still works.
- Migration journal comparison before publishing and optional format-1 journal metadata checked by verify and restore preparation.
- READY summaries include manifest creation time; concurrent removal is skipped and malformed manifests fail clearly.
- Recovery command directory overrides, source-only startup check and original plus cleanup failure reporting.

### Recovery and validation fixes

- Default recovery selects the newest READY directory even when an older manifest is damaged.
- Borrowed handles retain their integer settings; migration rows use lossless statement-local integers and the main schema.
- Restore refuses the live database's reserved sidecar paths. Manifest metadata is validated on creation and reading.

### Initial capabilities

- `db:backup create|list|verify|restore-prepare|prune` ace command, provider binding `sqlite.backup` and `node ace configure` (writes `config/backup.ts`, registers provider and command).
- Immutable bundles: one-step online copy, full `integrity_check` and `foreign_key_check`, SHA-256 manifest, `READY` written last.
- Prepare-only restore: stages and verifies a copy, refuses the live path, existing targets and stale `-wal`/`-shm`/`-journal` sidecars. Lock-free.
- Cooperative directory lock held by an exclusive SQLite transaction; released by the OS when the holder dies.
- Prune keeps the newest N READY bundles and removes unfinished bundles left by a crashed create, both under the lock.
- `BackupException` with six codes.

### Fixed (independent review)

- Create never deletes a path it did not create; a name collision is `E_BACKUP_UNSAFE`.
- Bundle names must carry a real date in 2000-9999; a newest bundle dated more than 24 h after the clock is refused instead of followed.
- Restore compares real paths (symlinked folders), treats dangling sidecar symlinks as present and reports a missing target folder as `E_BACKUP_UNSAFE`.
- Symlinked bundles are not bundles. Backup folders are compared with the live file as real paths.
- Hashing streams in 1 MiB chunks (no 2 GiB limit, constant memory).
- A non-SQLite or non-file live path is `E_BACKUP_SOURCE`; a missing bundle file is `E_BACKUP_INVALID`; a damaged lock file is emptied and reused.
- `manifest.createdAt` records the real clock time. Windows is excluded in `package.json`.
- Restore follows symlink chains on the live path even when they dangle, refuses targets inside the backup folder and passes target-side errors (permissions, a full disk) through instead of `E_BACKUP_NOT_FOUND`.
- Create reports "already exists" only for EEXIST; other folder errors pass through.
- Damaged-lock recovery opens the lock file with `O_NOFOLLOW | O_NONBLOCK` and truncates the descriptor, so a swapped-in symlink or FIFO is refused.
- Verify of the newest bundle that prune removes mid-check is `E_BACKUP_NOT_FOUND`, not `E_BACKUP_INVALID`.
- Paths are resolved as the kernel resolves them. A Lucid filename such as `alias/../live.db`, where `alias` is a symlink, used to back up the file the text pointed to rather than the one the app opens. Restore, the backup folder and the lock now use the same resolver.
- Restore re-checks the staged path after the copy and its cleanup removes only the file it created.
